package browse

import (
	"context"
	"fmt"
	"image/color"
	"strconv"
	"strings"
	"time"

	tea "charm.land/bubbletea/v2"
	"github.com/eliukblau/pixterm/pkg/ansimage"

	"github.com/stupside/castor/cmd/castor/internal/browse/tmdb"
)

// Poster cells approximate the 2:3 movie ratio (half-blocks double the rows).
const (
	posterCols = 27
	posterRows = 20
)

// hoverDebounce collapses cursor movement bursts to avoid requests per row.
const hoverDebounce = 120 * time.Millisecond

// inspector manages the right-hand panel with lazy poster and metadata caches.
type inspector struct {
	ctx    context.Context
	client Catalog
	styles styles

	posters       map[string]string        // posterPath -> rendered ANSI, empty once a fetch failed
	details       map[string]*tmdb.Details // detailKey -> details, nil once a fetch failed
	posterPending string
	detailPending map[string]bool
	tok           int // debounce token; only the latest hover settles
}

func newInspector(ctx context.Context, client Catalog) inspector {
	return inspector{
		ctx:           ctx,
		client:        client,
		posters:       map[string]string{},
		details:       map[string]*tmdb.Details{},
		detailPending: map[string]bool{},
	}
}

// hover is called on every selection change; only the final tick survives the token check.
func (in *inspector) hover() tea.Cmd {
	in.tok++
	return hoverSettleCmd(in.tok)
}

// update consumes async messages for settled hovers and ready assets.
func (in *inspector) update(msg tea.Msg, sel *tmdb.SearchResult) tea.Cmd {
	switch msg := msg.(type) {
	case hoverSettleMsg:
		if msg.tok != in.tok || sel == nil {
			return nil
		}
		return in.load(*sel)
	case posterReadyMsg:
		in.posters[msg.posterPath] = msg.ansi
		if msg.posterPath == in.posterPending {
			in.posterPending = ""
		}
		return nil
	case detailsReadyMsg:
		delete(in.detailPending, msg.key)
		in.details[msg.key] = msg.d
		return nil
	}
	return nil
}

// load skips what is cached, failed or in flight.
func (in *inspector) load(r tmdb.SearchResult) tea.Cmd {
	return tea.Batch(in.loadPoster(r), in.loadDetails(r))
}

func (in *inspector) loadPoster(r tmdb.SearchResult) tea.Cmd {
	if r.PosterPath == "" || in.posterPending == r.PosterPath {
		return nil
	}
	if _, ok := in.posters[r.PosterPath]; ok {
		return nil
	}
	in.posterPending = r.PosterPath
	return fetchPosterCmd(in.ctx, in.client, r.PosterPath)
}

func (in *inspector) loadDetails(r tmdb.SearchResult) tea.Cmd {
	key := detailKey(r.MediaType, r.ID)
	if _, done := in.details[key]; done {
		return nil
	}
	if in.detailPending[key] {
		return nil
	}
	in.detailPending[key] = true
	return detailsCmd(in.ctx, in.client, r.MediaType, r.ID)
}

// view renders the column, clamped to height rows; lipgloss rewrites ANSI, so poster strings bypass it.
func (in inspector) view(sel *tmdb.SearchResult, height int) string {
	if sel == nil {
		return blankRect(posterCols, height)
	}
	r := *sel

	poster := blankRect(posterCols, posterRows)
	if ansi := in.posters[r.PosterPath]; ansi != "" {
		poster = ansi
	}

	title := r.DisplayTitle()
	if y := r.Year(); y != "" {
		title = fmt.Sprintf("%s (%s)", title, y)
	}
	title = truncate(title, posterCols)

	d := in.details[detailKey(r.MediaType, r.ID)]
	info, tagline, cast := metaLines(r, d, posterCols)

	// Poster fixed; overview flexes into remaining vertical space.
	meta := []string{"", in.styles.metaTitle.Render(title)}
	if info != "" {
		meta = append(meta, in.styles.muted.Render(info))
	}
	if tagline != "" {
		meta = append(meta, in.styles.tagline.Render(tagline))
	}
	meta = append(meta, "") // spacer before the overview

	castLines := 0
	if cast != "" {
		castLines = 1
	}
	overviewH := max(height-posterRows-len(meta)-castLines, 0)
	if overviewH > 0 {
		meta = append(meta, in.styles.overview.MaxHeight(overviewH).Render(r.Overview))
	}
	if cast != "" {
		meta = append(meta, in.styles.muted.Render(cast))
	}
	return clampRows(poster+"\n"+strings.Join(meta, "\n"), height)
}

type posterReadyMsg struct {
	posterPath string
	ansi       string
	err        error
}

type detailsReadyMsg struct {
	key string
	d   *tmdb.Details
	err error
}

type hoverSettleMsg struct{ tok int }

func hoverSettleCmd(tok int) tea.Cmd {
	return tea.Tick(hoverDebounce, func(time.Time) tea.Msg { return hoverSettleMsg{tok: tok} })
}

func detailsCmd(ctx context.Context, c Catalog, media tmdb.Media, id int) tea.Cmd {
	key := detailKey(media, id)
	return func() tea.Msg {
		d, err := c.Details(ctx, media, id)
		return detailsReadyMsg{key: key, d: d, err: err}
	}
}

func detailKey(media tmdb.Media, id int) string { return string(media) + ":" + strconv.Itoa(id) }

// fetchPosterCmd renders the poster to ANSI escapes; half-blocks show 2 pixels per cell.
func fetchPosterCmd(ctx context.Context, c Catalog, posterPath string) tea.Cmd {
	return func() tea.Msg {
		body, err := c.Poster(ctx, posterPath)
		if err != nil {
			return posterReadyMsg{posterPath: posterPath, err: err}
		}
		defer func() { _ = body.Close() }()

		// NoDithering uses true-color; ScaleModeResize fits exactly to prevent layout shift.
		img, err := ansimage.NewScaledFromReader(
			body,
			posterRows*2, posterCols,
			color.Transparent,
			ansimage.ScaleModeResize,
			ansimage.NoDithering,
		)
		if err != nil {
			return posterReadyMsg{posterPath: posterPath, err: err}
		}
		return posterReadyMsg{posterPath: posterPath, ansi: img.Render()}
	}
}

// metaLines clamps each line; rating from list, runtime/genres/cast from details.
func metaLines(r tmdb.SearchResult, d *tmdb.Details, width int) (info, tagline, cast string) {
	var parts []string
	if r.VoteAverage > 0 {
		parts = append(parts, fmt.Sprintf("★ %.1f", r.VoteAverage))
	}
	if d != nil {
		if rt := formatRuntime(d.RuntimeMinutes()); rt != "" {
			parts = append(parts, rt)
		}
		if names := d.GenreNames(); len(names) > 0 {
			parts = append(parts, strings.Join(names, ", "))
		}
	}
	info = truncate(strings.Join(parts, " · "), width)

	if d != nil {
		tagline = truncate(d.Tagline, width)
		if c := d.TopCast(3); len(c) > 0 {
			cast = truncate("With "+strings.Join(c, ", "), width)
		}
	}
	return info, tagline, cast
}

func formatRuntime(minutes int) string {
	if minutes <= 0 {
		return ""
	}
	h, m := minutes/60, minutes%60
	switch {
	case h > 0 && m > 0:
		return fmt.Sprintf("%dh %dm", h, m)
	case h > 0:
		return fmt.Sprintf("%dh", h)
	default:
		return fmt.Sprintf("%dm", m)
	}
}
