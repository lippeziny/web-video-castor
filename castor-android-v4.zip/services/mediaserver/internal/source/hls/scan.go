package hls

import (
	"errors"
	"fmt"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/stupside/castor/services/mediaserver/internal/source/timeline"
)

// listing is a media playlist read line by line, each segment carrying every tag that applies to it.
type listing struct {
	segments []timeline.Segment
	closed   bool
	start    *timeline.Start
	// relaxed is a segment or init resource named with an extension a default reader rejects.
	relaxed bool
}

// scanMedia reads a media playlist whose references resolve against base, where it arrived from.
func scanMedia(body string, base *url.URL) (listing, error) {
	if !strings.HasPrefix(strings.TrimLeft(body, "\uFEFF \t\r\n"), signature) {
		return listing{}, errors.New("not an HLS playlist")
	}
	var (
		out      listing
		sequence int64
		pending  timeline.Segment
		key      timeline.Key
		explicit bool
		init     *timeline.Map
		gap      bool
		seam     bool
		// ends is where each resource's last byte range ended, for a range that states no offset.
		ends = map[string]int64{}
	)
	for line := range strings.Lines(body) {
		line = strings.TrimSpace(strings.TrimPrefix(line, "\uFEFF"))
		tag, value, _ := strings.Cut(line, ":")
		switch {
		case line == "" || (strings.HasPrefix(line, "#") && !strings.HasPrefix(line, "#EXT")):
		case tag == timeline.TagMediaSequence:
			n, err := strconv.ParseInt(value, 10, 64)
			if err != nil {
				return listing{}, fmt.Errorf("reading %s: %w", line, err)
			}
			sequence = n
		case tag == timeline.TagEndList:
			out.closed = true
		case tag == timeline.TagStart:
			// EXT-X-START is a hint: one without a usable offset is skipped, not a reason to refuse the playlist.
			a := attributes(value)
			if offset, err := strconv.ParseFloat(a["TIME-OFFSET"], 64); err == nil {
				out.start = &timeline.Start{Offset: seconds(offset), Precise: a["PRECISE"] == "YES"}
			}
		case tag == timeline.TagInf:
			duration, _, _ := strings.Cut(value, ",")
			d, err := strconv.ParseFloat(duration, 64)
			if err != nil {
				return listing{}, fmt.Errorf("reading %s: %w", line, err)
			}
			pending.Duration = seconds(d)
		case tag == timeline.TagByteRange:
			span, ok := byteRange(value)
			if !ok {
				return listing{}, fmt.Errorf("reading %s: not length[@offset]", line)
			}
			pending.Range = span
		case tag == timeline.TagDiscontinuity:
			seam = true
		case tag == timeline.TagGap:
			gap = true
		case tag == timeline.TagKey:
			a := attributes(value)
			key, explicit = timeline.Key{}, false
			if method := a["METHOD"]; method != "" && !strings.EqualFold(method, "NONE") {
				uri, err := base.Parse(a["URI"])
				if err != nil {
					return listing{}, fmt.Errorf("reading %s: %w", line, err)
				}
				key = timeline.Key{Method: method, URI: uri.String(), IV: a["IV"], Format: a["KEYFORMAT"]}
				explicit = key.IV != ""
			}
		case tag == timeline.TagMap:
			a := attributes(value)
			uri, err := base.Parse(a["URI"])
			if err != nil {
				return listing{}, fmt.Errorf("reading %s: %w", line, err)
			}
			// An init range that states no offset starts at the resource's first byte; no segment precedes it.
			span, ok := byteRange(a["BYTERANGE"])
			if !ok {
				return listing{}, fmt.Errorf("reading %s: BYTERANGE is not length[@offset]", line)
			}
			span.Offset = max(span.Offset, 0)
			// A key in force at the MAP encrypts the init section too, and names its IV outright.
			init = &timeline.Map{URI: uri.String(), Range: span, Key: key}
			out.relaxed = out.relaxed || relaxedName(a["URI"])
		case strings.HasPrefix(line, "#"):
		default:
			uri, err := base.Parse(line)
			if err != nil {
				return listing{}, fmt.Errorf("reading segment %q: %w", line, err)
			}
			pending.URI = uri.String()
			if pending.Range.Length > 0 && pending.Range.Offset < 0 {
				pending.Range.Offset = ends[pending.URI]
			}
			ends[pending.URI] = pending.Range.Offset + pending.Range.Length
			pending.Key, pending.Map = key, init
			// Without an IV the sequence number is the IV, and castor renumbers: it must travel stated.
			if key != (timeline.Key{}) && !explicit {
				pending.Key.IV = fmt.Sprintf("0x%032x", sequence)
			}
			pending.Place = timeline.Place{Start: sequence, End: sequence + 1}
			pending.Seam = seam
			out.relaxed = out.relaxed || relaxedName(line)
			// A gap lists media that does not exist, so what follows it is past a break the origin declared.
			if gap {
				seam = true
			} else {
				out.segments = append(out.segments, pending)
				seam = false
			}
			sequence++
			pending, gap = timeline.Segment{}, false
		}
	}
	return out, nil
}

// byteRange reads length[@offset]; an absent offset is marked negative, to continue the resource's last range, and a value that is neither is not ok.
func byteRange(value string) (timeline.Range, bool) {
	if value == "" {
		return timeline.Range{}, true
	}
	length, offset, stated := strings.Cut(value, "@")
	n, err := strconv.ParseInt(length, 10, 64)
	if err != nil || n < 0 {
		return timeline.Range{}, false
	}
	if !stated {
		return timeline.Range{Offset: -1, Length: n}, true
	}
	o, err := strconv.ParseInt(offset, 10, 64)
	return timeline.Range{Offset: o, Length: n}, err == nil && o >= 0
}

// attributes reads an attribute list, quoted values keeping their commas.
func attributes(list string) map[string]string {
	out := map[string]string{}
	for list != "" {
		name, rest, ok := strings.Cut(list, "=")
		if !ok {
			break
		}
		var value string
		if quoted, ok := strings.CutPrefix(rest, `"`); ok {
			value, rest, _ = strings.Cut(quoted, `"`)
		} else {
			value, rest, _ = strings.Cut(rest, ",")
		}
		out[strings.TrimSpace(name)] = value
		list = strings.TrimLeft(rest, ", ")
	}
	return out
}

func seconds(s float64) time.Duration { return time.Duration(s * float64(time.Second)) }
